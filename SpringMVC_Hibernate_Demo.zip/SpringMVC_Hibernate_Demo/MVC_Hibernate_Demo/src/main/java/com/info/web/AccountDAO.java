package com.info.web;

import java.util.List;

import com.info.entity.Account;

public interface AccountDAO {

	public List<Account> getAllAccount();
}
