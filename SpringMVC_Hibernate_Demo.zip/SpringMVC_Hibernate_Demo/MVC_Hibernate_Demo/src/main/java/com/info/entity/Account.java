package com.info.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Account {

	@Id
	private int accountid;
	private String accountHoldername;
	private String address;
	private int balance;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(String accountHoldername, String address, int balance) {
		super();
		this.accountHoldername = accountHoldername;
		this.address = address;
		this.balance = balance;
	}
	
	
	public int getAccountid() {
		return accountid;
	}
	public void setAccountid(int accountid) {
		this.accountid = accountid;
	}
	public String getAccountHoldername() {
		return accountHoldername;
	}
	public void setAccountHoldername(String accountHoldername) {
		this.accountHoldername = accountHoldername;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accountid=" + accountid + ", accountHoldername=" + accountHoldername + ", address=" + address
				+ ", balance=" + balance + "]";
	}
	
	
	
}//end class
