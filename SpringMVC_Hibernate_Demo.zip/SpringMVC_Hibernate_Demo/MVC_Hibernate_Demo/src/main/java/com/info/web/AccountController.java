package com.info.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.info.entity.Account;

@Controller
public class AccountController {
	
	@Autowired
	private AccountDAO accountDAO;

	public AccountController() {
		System.out.println("Account controller Constructor Called ....");
	}

	@RequestMapping("/")
	public String handleFirstReq(Model model)
	{
		System.out.println(" inside Handle First Req Method() ... ");
		
		List<Account> list =  accountDAO.getAllAccount();
		
		model.addAttribute("accounts", list);
		
		
		return "index";
	}
}
